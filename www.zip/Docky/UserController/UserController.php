<?php
namespace Docky\UserController;
class UserController {

}
$uc = new UserController();
