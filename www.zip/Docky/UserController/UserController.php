<?php
namespace Docky\UserController;
class UserController {
  public function __construct($DB){
    $this->DB = $DB;
  }
  public function checkauth(){
    if (isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0){
      return "Auth";
    }else{
      if (!isset($_COOKIE['protected_auth_token'])){
        return "Not";
      }else{
        $res = $this->DB->query("SELECT * FROM `users`");
        $finded = 0;
        $protected_auth_token = $_COOKIE['protected_auth_token'];
        while ($row = mysqli_fetch_assoc($res)){
          $usermd5 = md5($row['username']);
          $emailmd5 = md5($row['email']);
          $passwordmd5 = md5($row['password']);
          $protected_auth_token_check = md5($usermd5.$emailmd5.$passwordmd5);
          if ($protected_auth_token == $protected_auth_token_check){
            $finded = 1;
            if ($row['ban'] == "1"){
              echo "Not";
              break;
            }
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['password'] = $row['password'];
            $_SESSION['privilegies'] = $row['privilegies'];
            $_SESSION['balance'] = $row['balance'];
            $_SESSION['ban'] = $row['ban'];
            if ($row['ban'] != "1"){
              return "Auth";
            }
          }
        }
        if ($finded == 0){
          return "Not";
        }
      }
    }
  }
  public function getvar($var){
    if ($this->checkauth() == "Auth")
      return $_SESSION[$var];
    else{
      die("Hack detected!User not auth");
    }
  }
}
