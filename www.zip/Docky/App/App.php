<?php
namespace Docky\App;
class App {

}
$app = new App;
