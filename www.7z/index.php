<?php
session_start();
if (isset($_GET['logout'])){
  session_destroy();
  if (isset($_COOKIE['protected_auth_token'])){
    unset($_COOKIE['protected_auth_token']);
    setcookie('protected_auth_token', null, -1);
  }
  header("Location: ./");
}
require_once __DIR__.'/Docky/autoload.php';
use Docky\App\App;
use Docky\DB\DB;
use Docky\UserController\UserController;

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- META SEO -->
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://bspanel.org/">
  <meta property="og:site_name" content="BSPanel">
  <meta property="og:keywords" content="BSPanel,Game hosting,Server hosting,Хостинг игровых серверов,Хостинг сервера,minecraft,csgo,cs 1.6,css v34,samp,crmp"><meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:site" content="@bspanelorg">
  <meta property="twitter:site:id" content="@bspanelorg">
  <meta property="twitter:creator" content="@bspanelorg">
  <meta property="twitter:creator:id" content="@bspanelorg">
  <!-- META SEO -->
  <title>Serv.Host</title>
  <link rel="stylesheet" href="./src/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</head>
<body>
<!-- POPUPS -->
<div class="popup" popupsystem="register">
  <div class="popup__content">
    <div class="popup-cross"></div>
    <form class="popup__form" id="register_form" method="post">
      <span>Регистрация</span>
      <input type="text" placeholder="Введите логин">
      <input type="email" placeholder="Введите почту">
      <input type="password" placeholder="Введите пароль">
      <input type="password" placeholder="Введите пароль ещё раз">
      <button class="popup__form__btn">Зарегистрироваться</button>
      <p id="popupOpen" popupid="login">Есть аккаунт?Вы можете войти тут</p>
    </form>
  </div>
</div>
<div class="popup" popupsystem="login">
  <div class="popup__content">
    <div class="popup-cross"></div>
    <form class="popup__form" id="login_form" method="post">
      <span>Вход</span>
      <input type="text" placeholder="Введите логин">
      <input type="password" placeholder="Введите пароль">
      <button class="popup__form__btn">Войти</button>
      <p id="popupOpen" popupid="register">Нету аккаунта?Зарегистрируйтесь тут</p>
    </form>
  </div>
</div>
<!-- POPUPS -->
<div class="wrapper">
  <!-- CONTAINER -->
  <div class="container">
    <!-- TOP -->
    <nav>
      <div class="burger-cross">⨉</div>
      <div class="nav__menu">
        <span class="nav__logo">BSPanel</span>
        <ul class="nav__list">
          <li class="nav__item">
            <i class="fa-solid fa-house-chimney nav__icon"></i>
            <p class="nav__text">Главная</p>
          </li>
          <li class="nav__item">
            <i class="fa-solid fa-newspaper nav__icon"></i>
            <p class="nav__text">Новости</p>
          </li>
          <li class="nav__item">
            <i class="fa-solid fa-cart-shopping nav__icon"></i>
            <p class="nav__text">Услуги</p>
          </li>
          <li class="nav__item">
            <i class="fa-solid fa-question nav__icon"></i>
            <p class="nav__text">Ответы на вопросы</p>
          </li>
          <li class="nav__item">
            <i class="fa-solid fa-user nav__icon"></i>
            <p class="nav__text">Контакты</p>
          </li>
        </ul>
      </div>
      <div class="nav__account">
        <ul class="nav__list">
          <?php
          if ($uc->checkauth() == "Auth"){
            echo '<li class="nav__item" id="redirectOpen" redirecturi="./account.php">
              <i class="fa-solid fa-user nav__icon"></i>
              <p class="nav__text">Личный кабинет</p>
            </li>
            <li class="nav__item" id="balance">
              <i class="fa-solid fa-money-bill nav__icon"></i>
              <p class="nav__text">Баланс: '.$uc->getvar('balance').' грн.</p>
            </li>
            <li class="nav__item" id="redirectOpen" redirecturi="./?logout">
              <i class="fa-solid fa-right-from-bracket nav__icon"></i>
              <p class="nav__text"></p>
            </li>';
          }else{
            echo '<li class="nav__item" id="popupOpen" popupid="register">
              <i class="fa-solid fa-user nav__icon"></i>
              <p class="nav__text">Зарегистрироваться</p>
            </li>';
          }
          ?>
        </ul>
      </div>
      <div class="burger">☰</div>
    </nav>
    <!-- TOP -->
    <!-- MAIN -->
    <main class="main__container">
      <div class="main__container__menu__list">
        <!-- USER MENU -->
        <section class="main__container__menu">
          <span class="main__container__menu__title">
            <i class="fa-solid fa-bars"></i>
            <p>Пользователь</p>
          </span>
          <ul class="main__container__menu_items">
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>Игровые сервера</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-server"></i>
              <p>Арендовать хостинг</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gear"></i>
              <p>Услуга контроль</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-question"></i>
              <p>Тех. Поддержка</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-circle-question"></i>
              <p>Ответы на вопросы</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-brands fa-forumbee"></i>
              <p>Форум</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-brands fa-discord"></i>
              <p>Discord</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-newspaper"></i>
              <p>Новости хостинга</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-desktop"></i>
              <p>Мониторинг</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-message"></i>
              <p>Отзывы</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-user-doctor"></i>
              <p>Вакансии</p>
            </li>
          </ul>
        </section>
        <!-- USER MENU -->
        <!-- OUR SERVICES -->
        <section class="main__container__menu">
          <span class="main__container__menu__title">
            <i class="fa-solid fa-bars"></i>
            <p>Услуги</p>
          </span>
          <ul class="main__container__menu_items">
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>Проверка плагинов</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-server"></i>
              <p>Покупка привилегий</p>
            </li>
            <!-- GAMES -->
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>Counter Strike 1.6</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>Counter Strike GO</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>Counter Strike Source</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>Counter Strike Source v34</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>San Andreas Multiplayer</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>Criminal Russia Multiplayer</p>
            </li>
            <li class="main__container__menu__item">
              <i class="fa-solid fa-gamepad"></i>
              <p>Minecraft</p>
            </li>
            <!-- GAMES -->
          </ul>
        </section>
        <!-- OUR SERVICES -->
      </div>
      <div class="main__container__content">
        <span class="main__container__path">
          BSPanel v3 >
          <p class="path-violet">Главная страница</p>
        </span>
        <img src="https://cutewallpaper.org/21/4k-gif-wallpaper/The-Matrix-Live-Wallpaper-For-Pc-Gif-Siboneycubancuisine.com.gif" class="main__container__banner" alt="">
        <div class="order__list">
          <div class="order__item">
            <img src="https://www.csgo-game.ru/files/news_imgs/1629916634.jpg" class="order__game" alt="">
            <p>Counter-Strike: 1.6</p>
            <p>2 грн. / Слот</p>
            <button class="order__btn" name="button">Арендовать Сервер</button>
          </div>
          <div class="order__item">
            <img src="https://icons.iconarchive.com/icons/titch-ix/game/256/CSS-icon.png" class="order__game" alt="">
            <p>Counter-Strike: Source</p>
            <p>5 грн. / Слот</p>
            <button class="order__btn" name="button">Арендовать Сервер</button>
          </div>
          <div class="order__item">
            <img src="https://icons.iconarchive.com/icons/titch-ix/game/256/CSS-icon.png" class="order__game" alt="">
            <p>Counter-Strike: Source v34</p>
            <p>5 грн. / Слот</p>
            <button class="order__btn" name="button">Арендовать Сервер</button>
          </div>
          <div class="order__item">
            <img src="https://www.freeiconspng.com/thumbs/csgo-icon/csgo-icon-4.png" class="order__game" alt="">
            <p>Counter-Strike: GO</p>
            <p>5 грн. / Слот</p>
            <button class="order__btn" name="button">Арендовать Сервер</button>
          </div>
          <div class="order__item">
            <img src="https://www.sovahost.net/wp-content/uploads/2020/02/samp-logo-png-6.png" class="order__game" alt="">
            <p>San Andreas Multiplayer</p>
            <p>5 грн. / Слот</p>
            <button class="order__btn" name="button">Арендовать Сервер</button>
          </div>
          <div class="order__item">
            <img src="http://www.techfacts007.in/wp-content/uploads/2018/05/gta_san_andreas_by_dj_fahr-d5oa3bq-300x300.png" class="order__game" alt="">
            <p>San Andreas</p>
            <p>5 грн. / Слот</p>
            <button class="order__btn" name="button">Арендовать Сервер</button>
          </div>
          <div class="order__item">
            <img src="https://upload.wikimedia.org/wikipedia/en/7/78/Multi_Theft_Auto_logo.png" class="order__game" alt="">
            <p>Criminal Russian</p>
            <p>5 грн. / Слот</p>
            <button class="order__btn" name="button">Арендовать Сервер</button>
          </div>
          <div class="order__item">
            <img src="https://img.icons8.com/bubbles/500/minecraft-logo--v1.png" class="order__game" alt="">
            <p>Minecraft</p>
            <p>3 грн. / Слот</p>
            <button class="order__btn" name="button">Арендовать Сервер</button>
          </div>
        </div>
      </div>
    </main>
    <!-- MAIN -->
  </div>
  <!-- CONTAINER -->
</div>
<script type="text/javascript" defer>
var nav = document.querySelector(".wrapper .container nav"),
    burger = document.querySelector(".wrapper .container nav .burger"),
    burgercross = document.querySelector(".wrapper .container nav .burger-cross"),
    popupsopen = document.querySelectorAll("#popupOpen"),
    popups = document.querySelectorAll(".popup"),
    redirectsopen = document.querySelectorAll("#redirectOpen");
burger.onclick = () => {
  nav.classList.add("activated");
};
burgercross.onclick = () => {
  nav.classList.remove("activated");
};
redirectsopen.forEach(item => {
  if (!item.getAttribute("redirecturi")){
    document.write("Redirect Error!RedirectURI not found on element => " + item.innerHTML);
    return;
  }
  var redirecturi = item.getAttribute("redirecturi");
  item.onclick = () => {
    window.location = redirecturi;
  };
});
popupsopen.forEach(item => {
  if (!item.getAttribute("popupid")){
    document.write("Popup Error!PopupID not found on element => " + item.innerHTML);
    return;
  }
  var popupid = item.getAttribute("popupid");
  item.onclick = () => {
    popups.forEach(ij => {
      if (!ij.getAttribute("popupsystem")){
        document.write("Popup Error!PopupSystem not found on element => " + ij.innerHTML);
        return;
      }else{
        if (ij.getAttribute("popupsystem") == popupid){
          popups.forEach(ik => {
            try{
              ik.classList.remove("active");
            }
            catch (Error){
              //OK Error
            }
          });
          ij.classList.add("active");
          ij.querySelector(".popup__content .popup-cross").onclick = () => {
            ij.classList.add("hiding");
            setTimeout(() => {
              ij.classList.remove("active");
              ij.classList.remove("hiding");
            }, 900);
          };
        }else{
          // Author BubbleGum
        }
      }
    });
  };
});
// FORMS CONTROLL
var register_form = document.querySelector("#register_form"),
    login_form    = document.querySelector("#login_form");
register_form.onsubmit = (e) => {
  e.preventDefault();
  var login = e['srcElement'][0].value,
      email = e['srcElement'][1].value,
      passw = e['srcElement'][2].value,
      passa = e['srcElement'][3].value;
  $.post( "data.php", { login: login, email: email, password: passw, password_again: passa, post_type: "register" }, function( data ) {
    switch (data) {
      case "pwderr413":
        alert("Passwords dont match!");
        break;
      case "logerr327":
        alert("Login smaller than 6 or bigger than 16 symbols!");
        break;
      case "pwderr327":
        alert("Password smaller than 6 or bigger than 16 symbols!");
        break;
      case "accfound":
        alert("Account with this email or login already registered!");
        break;
      case "error":
        alert("Server error in registering!");
        break;
      case "success":
        alert("Account succesfully registered!Now you can login");
        e.target.parentElement.parentElement.classList.add("hiding");
        setTimeout(() => {
          e.target.parentElement.parentElement.classList.remove("active");
          e.target.parentElement.parentElement.classList.remove("hiding");
        }, 900);
        break;
      case "emaierr347":
        alert("Email bigger than 32 symbols!");
        break;
    }
  }, "text");
};
login_form.onsubmit = (e) => {
  e.preventDefault();
  var login = e['srcElement'][0].value,
      passw = e['srcElement'][1].value;
  $.post( "data.php", { login: login, password: passw, post_type: "login" }, function( data ) {
    switch (data) {
      case "logerr327":
        alert("Login smaller than 6 or bigger than 16 symbols!");
        break;
      case "pwderr327":
        alert("Password smaller than 6 or bigger than 16 symbols!");
        break;
      case "accnotfound" || "accfailure":
        alert("Account not found!Or login and password not valid!");
        break;
      case "accsuspend":
        alert("Account was banned by rules violation");
        break;
      case "success":
        alert("You succesfully logined in account!");
        window.location.reload();
        e.target.parentElement.parentElement.classList.add("hiding");
        setTimeout(() => {
          e.target.parentElement.parentElement.classList.remove("active");
          e.target.parentElement.parentElement.classList.remove("hiding");
        }, 900);
        break;
    }
  }, "text");
};
<?php
if ($uc->checkauth() == "Auth"){
  echo 'function autoUpdater (){
    var login = "'.$uc->getvar("username").'",
        passw = "'.$uc->getvar("password").'";
    $.post( "data.php", { login: login, password: passw, post_type: "updater" }, function( data ) {
      if (data == "accsuspend"){
        window.location.reload();
      }
      if (data == "accnotfound"){
        window.location.reload();
      }
      if (data.includes("success;")){
        data = data.replace("success;","");
        document.querySelector("#balance p").innerText = "Баланс: " + data + " грн.";
      }
    }, "text");
    setTimeout(() => {
      autoUpdater()
    },800);
  }
  setTimeout(() => {
    autoUpdater()
  },1000);';
}
?>
</script>
</body>
</html>
