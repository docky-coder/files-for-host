<?php
require_once __DIR__."/App/App.php";
require_once __DIR__."/DB/DB.php";
require_once __DIR__."/UserController/UserController.php";
$uc = new Docky\UserController\UserController($DB);
