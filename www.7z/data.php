<?php
session_start();
require_once __DIR__.'/Docky/autoload.php';
use Docky\App\App;
use Docky\DB\DB;
use Docky\UserController\UserController;
$post_type = $_POST['post_type'];
switch ($post_type) {
  case "register":
    $login = $_POST['login'];
    $email = $_POST['email'];
    $passw = $_POST['password'];
    $passa = $_POST['password_again'];
    $error = 0;
    if ($passw == $passa){
      if (strlen($login) < 6 || strlen($login) > 16){
        echo "logerr327";
        $error += 1;
      }
      if (strlen($passw) < 6 || strlen($passw) > 16){
        echo "pwderr327";
        $error += 1;
      }
      if (strlen($email) > 32){
        echo "emaierr347";
        $error += 1;
      }
      if ($error == 0){
        $result = $DB->query("SELECT * FROM `users` WHERE username = '$login' OR email = '$email'");
        if (mysqli_num_rows($result)){
          echo "accfound";
        }else{
          $res = $DB->query("INSERT INTO `users` (username,email,password) VALUES('$login','$email','$passw')");
          if ($res){
            echo "success";
          }else{
            echo "error";
          }
        }
      }
    }else{
      echo "pwderr413";
      $error += 1;
    }
    break;
  case "login":
    $login = $_POST['login'];
    $passw = $_POST['password'];
    $result = $DB->query("SELECT * FROM `users` WHERE username = '$login' AND password = '$passw'");
    if (mysqli_num_rows($result)){
      $row = mysqli_fetch_assoc($result);
      if ($row['ban'] == "1"){
        echo "accsuspend";
        break;
      }
      $_SESSION['user_id'] = $row['id'];
      $_SESSION['username'] = $row['username'];
      $_SESSION['email'] = $row['email'];
      $_SESSION['password'] = $row['password'];
      $_SESSION['privilegies'] = $row['privilegies'];
      $_SESSION['balance'] = $row['balance'];
      $_SESSION['ban'] = $row['ban'];
      if ($row['ban'] != "1"){
        setcookie("protected_auth_token", md5(md5($row['username']).md5($row['email']).md5($row['password'])), time()+2678400);
        echo "success";
      }
    }else{
      echo "accnotfound";
    }
    break;
  case "updater":
    $login = $_POST['login'];
    $passw = $_POST['password'];
    $result = $DB->query("SELECT * FROM `users` WHERE username = '$login' AND password = '$passw'");
    if (mysqli_num_rows($result)){
      $row = mysqli_fetch_assoc($result);
      if ($row['ban'] == "1"){
        echo "accsuspend";
        break;
      }
      $_SESSION['user_id'] = $row['id'];
      $_SESSION['username'] = $row['username'];
      $_SESSION['email'] = $row['email'];
      $_SESSION['password'] = $row['password'];
      $_SESSION['privilegies'] = $row['privilegies'];
      $_SESSION['balance'] = $row['balance'];
      $_SESSION['ban'] = $row['ban'];
      if ($row['ban'] != "1"){
        echo "success;".$_SESSION['balance'];
      }
    }else{
      echo "accnotfound";
    }
    break;
}
?>
